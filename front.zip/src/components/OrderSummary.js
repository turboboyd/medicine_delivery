// src/components/OrderSummary.js
import React from "react";

const OrderSummary = () => {
  // Здесь будет форма итога заказа
  return <div>Итог заказа</div>;
};

export default OrderSummary;
